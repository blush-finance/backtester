# Minimum Variance Portfolio Investment Strategy

This package serves as an example on how a packaged quant strategy could look like.
